def keyphrase_openai(phrase):
    import openai
    with open("C:/Users/manas_nmr2rze/Desktop/Capstone/openai/key.txt") as f:
        
        contents = f.readlines()
        for i in contents:
            openai.api_key = i

    response = openai.Completion.create(
      model="text-davinci-003",
      prompt=phrase,
      temperature=.5,
      max_tokens=20,
      top_p=1,
      frequency_penalty=.8,
      presence_penalty=0
    )
    choice = response['choices']
    key = choice[0].text
    key = key.replace('\n\nKeywords:','')
    key = key.replace('\n','')
    return key

def keyphrase_yake(phrase,word_dict,audio_text, vid_text,time_list):
    from yake import KeywordExtractor as Yake
    yake = Yake(lan="en")
    yake_keyphrases = yake.extract_keywords(phrase)
    #print(yake_keyphrases)
    import yake
    
    kw_extractor = yake.KeywordExtractor()
    keywords = kw_extractor.extract_keywords(phrase)
    language = "en"
    max_ngram_size = 6
    deduplication_threshold = 0.8
    deduplication_algo = 'seqm'
    windowSize = 1
    numOfKeywords = 1

    custom_kw_extractor = yake.KeywordExtractor(lan=language, n=max_ngram_size, dedupLim=deduplication_threshold, dedupFunc=deduplication_algo, windowsSize=windowSize, top=numOfKeywords, features=None)
    keywords = custom_kw_extractor.extract_keywords(phrase)
    
    
       


    for kw in keywords:
        print(kw[0])
    keyphrase = kw[0]
    keyphr = keyphrase.lower()
    keyph = keyphr.split(' ')
    start, end = substring_pos(phrase, keyphrase)
    key=keyphrase.upper()
    try:
        stime = time_list[start][0]
        etime = time_list[end][1]
         
#         stime = word_dict[keyph[0]][0]
#         etime = word_dict[keyph[-1]][1]
        
        #print("")
        if keyphrase.lower()in audio_text.lower():
            response = str('Keyphrase is in audio....')
        elif keyphrase.lower()in vid_text.lower():
            response = str('Keyphrase is in visual text..')
        return key, stime, etime, response
    except:
        response = str('Keyphrase timestamps not found..')
        return key, response
    #print("=======================")
#     print(f"Keyphrase starting time: {stime} seconds")
#     print(f"Keyphrase ending time: {etime} seconds")
def keyphrase_suma(phrase,word_dict,audio_text, vid_text,time_list):
    from summa import keywords
    TR_keywords = keywords.keywords(phrase, scores=True)
    print(TR_keywords[0:15])

    from keybert import KeyBERT
    kw_model = KeyBERT(model='all-mpnet-base-v2')
    #kw_model = pickle.load(open('kw_model.pkl','rb'))
    keywords = kw_model.extract_keywords(phrase, 

                                         keyphrase_ngram_range=(1, 8), 

                                         stop_words='english', 

                                         highlight=False,

                                         top_n=1);

    keywords_list= list(dict(keywords).keys());

    keyphrase = keywords_list[0].lower();
    keyph = keyphrase.split(' ');
    start, end = substring_pos(phrase, keyphrase)
    key=keyphrase.upper()
    
    try:
        stime = time_list[start][0]
        etime = time_list[end][1]
         

        #print("")
        if keyphrase.lower()in audio_text.lower():
            response = str('Keyphrase is in audio....')
        elif keyphrase.lower()in vid_text.lower():
            response = str('Keyphrase is in visual text..')
        return key, stime, etime, response
    except:
        response = str('Keyphrase timestamps not found..')
        return key, response


def keyphrase_rake1(phrase,word_dict,audio_text, vid_text,time_list):
    from rake_nltk import Rake

    # Initialize the Rake object
    r = Rake()

    # Text to extract key phrases from
    text = phrase
    # Extract keywords
    r.extract_keywords_from_text(text)

    # Get the top 5 phrases
    results = r.get_ranked_phrases()[:3]
    keyph_list = []

    # Print the phrases
    for keyphrase in results:
        try:

            keyphr = keyphrase.lower()
            keyph = keyphr.split(' ')
            start, end = substring_pos(phrase, keyphrase)
            key=keyphrase.upper()

            try:
                stime = time_list[start][0]
                etime = time_list[end][1]


                #print("")
                if keyphrase.lower()in audio_text.lower():
                    response = str('Keyphrase is in audio....')
                elif keyphrase.lower()in vid_text.lower():
                    response = str('Keyphrase is in visual text..')
                keyph_list.append((key, stime, etime, response));
            except:
                response = str('Keyphrase timestamps not found..')
                keyph_list.append((key, response));

#             print(keyphrase.upper())
#             print("=======================")
#             print(f"Keyphrase starting time: {stime} seconds")
#             print(f"Keyphrase ending time: {etime} seconds")
        except:
            pass
    
    print(" Top three Keyphrases ".ljust(80, "-"))
    return keyph_list

def keyphrase_spacy(phrase,word_dict,audio_text, vid_text,time_list):
    import spacy

    # Load the English language model
    nlp = spacy.load('en_core_web_lg')

    # Text to extract keywords from
    text = phrase
    # Process the text with spaCy
    doc = nlp(text)

    # Extract keywords
#     keywords = []
#     for token in doc:
#         if not token.is_stop and token.pos_ in ['NOUN', 'PROPN','ADJECTIVE']:
#             keywords.append(token.text)
    keyphrases = set()
    for chunk in doc.noun_chunks:
        if len(chunk) > 1 and chunk.root.pos_ != 'PRON':
            keyphrases.add(chunk.text)
    keyphrases = list(keyphrases)
    keyphrase = keyphrases[0]
    start, end = substring_pos(phrase, keyphrase)
    key=keyphrase.upper()
    
    try:
        stime = time_list[start][0]
        etime = time_list[end][1]
         

        #print("")
        if keyphrase.lower()in audio_text.lower():
            response = str('Keyphrase is in audio....')
        elif keyphrase.lower()in vid_text.lower():
            response = str('Keyphrase is in visual text..')
        return key, stime, etime, response
    except:
        response = str('Keyphrase timestamps not found..')
        return key, response

#     keyphr = keyphrase.lower()
#     keyph = keyphr.split(' ')
#     try:
#         stime = word_dict[keyph[0]][0]
#         etime = word_dict[keyph[-1]][1]
#         keyphrase=keyphrase.upper()

#         return keyphrase, stime, etime
#     except:
#         return keyphrase
# #     return keyphrases[0]
def keyphrase_bart(phrase,word_dict,audio_text, vid_text,time_list):
#     import torch
    from transformers import BartTokenizer, BartForConditionalGeneration

    # Load the BART model and tokenizer
    model = BartForConditionalGeneration.from_pretrained('facebook/bart-large')
    tokenizer = BartTokenizer.from_pretrained('facebook/bart-large')

    # Define a sample input text
    input_text = phrase

    # Preprocess the input text
    input_ids = tokenizer.encode(input_text, add_special_tokens=True, return_tensors='pt')

    # Generate keyphrases using BART
    output = model.generate(input_ids, max_length=20, num_beams=4, early_stopping=True)
    keyphrase = tokenizer.decode(output[0], skip_special_tokens=True)

    # Print the generated keyphrases
#     print(keyphrase)

    start, end = substring_pos(phrase, keyphrase)
    key=keyphrase.upper()
    try:
        stime = time_list[start][0]
        etime = time_list[end][1]
         

        #print("")
        if keyphrase.lower()in audio_text.lower():
            response = str('Keyphrase is in audio....')
        elif keyphrase.lower()in vid_text.lower():
            response = str('Keyphrase is in visual text..')
        return key, stime, etime, response
    except:
        response = str('Keyphrase timestamps not found..')
        return key, response
    

   


def vader_sentiment(phrase):
    try:
        from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
        analyzer = SentimentIntensityAnalyzer()
        text = phrase
        scores = analyzer.polarity_scores(text)

        return scores
    except:
        return 'Sentiment analysis not possible'

def substring_pos(string, substring):
    start=0
    end=0
    text = punc_remover(string)
    ph = punc_remover(substring)
    text_l = list(text.split(sep=' '))
    ph_l = list(ph.split(sep=' '))


    for j in range(len(text_l)):
        if ph_l[0]== text_l[j]:
            count=0
            for i in range(len(ph_l)):
                if ph_l[i]== text_l[j+i]:
                    count+=1
            if count== len(ph_l):
                start = j
                end = start+len(ph_l)-1
                break
            else:
                continue
    return start, end
def punc_remover(text):
    import string

    # Remove punctuation using string module and filter function
    text = ''.join(filter(lambda char: char not in string.punctuation, text)).lower()
    return text

#Call to action 
import re

def product_claim(text,word_dict,audio_text, vid_text,time_list):
    import pickle
    import re
    pr_clm_phrases = pickle.load(open('pr_clm_phrases.pkl','rb'))

    # Split the text into sentences using regular expressions
    sentences = re.split('(?<!\w\.\w.)(?<![A-Z][a-z]\.)(?<=\.|\?|\!|\;)\s', text)
    # Iterate over each sentence and check if it contains the phrase
    result = []
    for sentence in sentences:
        for phrase in pr_clm_phrases:
            if phrase.lower() in sentence.lower():
                                
                start, end = substring_pos(text.lower(),sentence.lower())
                key = sentence
                try:
                    stime = time_list[start][0]
                    etime = time_list[end][1]


                    #print("")
                    if phrase.lower()in audio_text.lower():
                        response = str('product claim is in audio....')
                    elif phrase.lower()in vid_text.lower():
                        response = str('product claim is in visual text..')
                    result.append((key, stime, etime, response))
                    
#                     return key, stime, etime, response
                except:
                    response = str('timestamps not found..')
                    result.append((key, response))
                    
    result= list(set(result))                
    if len(result)==0:
        result.append('No product claim sentences found')
        return result
    else:
        header = 'Product claim statement :  '
        return header,result
                 
    

def product_details(text,word_dict,audio_text, vid_text,time_list):
    import pickle
    import re
    pr_dt_phrases = pickle.load(open('pr_dt_phrases.pkl','rb'))
    # Split the text into sentences using regular expressions
    sentences = re.split('(?<!\w\.\w.)(?<![A-Z][a-z]\.)(?<=\.|\?|\!|\;)\s', text)
    # Iterate over each sentence and check if it contains the phrase
    result = []
    for sentence in sentences:
        for phrase in pr_dt_phrases:
            if phrase.lower() in sentence.lower():
                                
                start, end = substring_pos(text.lower(),sentence.lower())
                key = sentence
                try:
                    stime = time_list[start][0]
                    etime = time_list[end][1]


                    #print("")
                    if phrase.lower()in audio_text.lower():
                        response = str('product detail is in audio....')
                    elif phrase.lower()in vid_text.lower():
                        response = str('product detail is in visual text..')
                    result.append((key, stime, etime, response))
                    
#                     return key, stime, etime, response
                except:
                    response = str('timestamps not found..')
                    result.append((key, response))
                    
    result= list(set(result))                
    if len(result)==0:
        result.append('No product detail sentences found')
        return result
    else:
        header = 'Product detail statement :  '
        return header,result
             
    

def product_offers(text,word_dict,audio_text, vid_text,time_list):
    import pickle
    import re
    pr_off_phrases = pickle.load(open('pr_off_phrases.pkl','rb'))
    # Split the text into sentences using regular expressions
    sentences = re.split('(?<!\w\.\w.)(?<![A-Z][a-z]\.)(?<=\.|\?|\!|\;)\s', text)
    # Iterate over each sentence and check if it contains the phrase
    result = []
    for sentence in sentences:
        for phrase in pr_off_phrases:
            if phrase.lower() in sentence.lower():
                                
                start, end = substring_pos(text.lower(),sentence.lower())
                key = sentence
                try:
                    stime = time_list[start][0]
                    etime = time_list[end][1]


                    #print("")
                    if phrase.lower()in audio_text.lower():
                        response = str('product offer is in audio....')
                    elif phrase.lower()in vid_text.lower():
                        response = str('product offer is in visual text..')
                    result.append((key, stime, etime, response))
                    
#                     return key, stime, etime, response
                except:
                    response = str('timestamps not found..')
                    result.append((key, response))
                
    result= list(set(result))                
    if len(result)==0:
        result.append('No product offer sentences found')
        return result
    else:
        header = 'Product offer statement :  '
        return header,result
           
    

def call_to_buy(text,word_dict,audio_text, vid_text,time_list):
    import pickle
    import re
    ctb_phrases = pickle.load(open('ctb_phrases.pkl','rb'))
    # Split the text into sentences using regular expressions
    sentences = re.split('(?<!\w\.\w.)(?<![A-Z][a-z]\.)(?<=\.|\?|\!|\;)\s', text)
    # Iterate over each sentence and check if it contains the phrase
    result = []
    for sentence in sentences:
        for phrase in ctb_phrases:
            if phrase.lower() in sentence.lower():
                                
                start, end = substring_pos(text.lower(),sentence.lower())
                key = sentence
                try:
                    stime = time_list[start][0]
                    etime = time_list[end][1]


                    #print("")
                    if phrase.lower()in audio_text.lower():
                        response = str('call to buy is in audio....')
                    elif phrase.lower()in vid_text.lower():
                        response = str('call to buy is in visual text..')
                    result.append((key, stime, etime, response))
                    
#                     return key, stime, etime, response
                except:
                    response = str('timestamps not found..')
                    result.append((key, response))
                    
                
    result= list(set(result))
    if len(result)==0:
        result.append('No call to buy sentences found')
        return result
    else:
        header = 'Call to buy statement :  '
        return header,result


def call_to_seek_info(text,word_dict,audio_text, vid_text,time_list):
    import pickle
    import re
    ctsmi_phrases = pickle.load(open('ctsmi_phrases.pkl','rb'))
    # Split the text into sentences using regular expressions
    sentences = re.split('(?<!\w\.\w.)(?<![A-Z][a-z]\.)(?<=\.|\?|\!|\;)\s', text)
    # Iterate over each sentence and check if it contains the phrase
    result = []
    for sentence in sentences:
        for phrase in ctsmi_phrases:
            if phrase.lower() in sentence.lower():
                                
                start, end = substring_pos(text.lower(),sentence.lower())
                key = sentence
                try:
                    stime = time_list[start][0]
                    etime = time_list[end][1]


                    #print("")
                    if phrase.lower()in audio_text.lower():
                        response = str('call to seek info is in audio....')
                    elif phrase.lower()in vid_text.lower():
                        response = str('call to seek info is in visual text..')
                    result.append((key, stime, etime, response))
                    
#                     return key, stime, etime, response
                except:
                    response = str('timestamps not found..')
                    result.append((key, response))
                    
                
    result= list(set(result))
    if len(result)==0:
        result.append('No call to seek more info sentences found')
        return result
    else:
        header = 'Call to seek more info statement :  '
        return header,result
def call_to_action(text,word_dict,audio_text, vid_text,time_list):
    import pickle
    import re
    cta_phrases = pickle.load(open('cta_phrases.pkl','rb'))
    # Split the text into sentences using regular expressions
    sentences = re.split('(?<!\w\.\w.)(?<![A-Z][a-z]\.)(?<=\.|\?|\!|\;)\s', text)
    # Iterate over each sentence and check if it contains the phrase
    result = []
    for sentence in sentences:
        for phrase in cta_phrases:
            if phrase.lower() in sentence.lower():
                                
                start, end = substring_pos(text.lower(),sentence.lower())
                key = sentence
                try:
                    stime = time_list[start][0]
                    etime = time_list[end][1]


                    #print("")
                    if phrase.lower()in audio_text.lower():
                        response = str('other call to action is in audio....')
                    elif phrase.lower()in vid_text.lower():
                        response = str('other call to action is in visual text..')
                    result.append((key, stime, etime, response))
                    
#                     return key, stime, etime, response
                except:
                    response = str('timestamps not found..')
                    result.append((key, response))
                    
                
    result= list(set(result))
    if len(result)==0:
        result.append('No other call to action sentences found')
        return result
    else:
        header = 'Other call to action statement :  '
        return header,result
