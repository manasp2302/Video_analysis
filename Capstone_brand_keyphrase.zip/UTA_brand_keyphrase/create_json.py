import json

def my_logo_json(video_uri):
    from UTA_brand_keyphrase import logo_df_generator
    #area_list, max_logo_list, logo_out=detect_logo.detect_logo(video_uri)
    logo_out_dict,logo_out,logo=logo_df_generator.predict_logo(video_uri)
    my_dict = logo_out
    my_logo = logo_out_dict
    
    my_json_out_dict = json.dumps(my_dict ,separator=(","))
    my_json_out_sum = json.dumps(my_logo)
    
    
    return my_json_out_sum, my_json_out_dict, logo

def create_json_logo_file(video_uri,path='C:/Users/manas_nmr2rze/Desktop/Capstone/Output/JSON_logo/' ):
    from UTA_brand_keyphrase import logo_df_generator
    import sys
    my_json_out_sum, my_json_out_dict,logo=my_logo_json(video_uri)
    filepath_1=path+logo+'_Summary.json'
    filepath_2=path+logo+'_Detail.json'
    
    with open(filepath_1, "w") as outfile:
        sys.stdout = filepath_1
        outfile.write(my_json_out_sum)
    with open(filepath_2, "w") as outfile:
        sys.stdout = filepath_2
        outfile.write(my_json_out_dict)
    sys.stdout = sys.__stdout__
    
    
