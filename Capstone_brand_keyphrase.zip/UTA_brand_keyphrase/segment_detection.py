"""Detect labels given a file path."""
def detect_shot_changes(video_link):
    video_client = videointelligence.VideoIntelligenceServiceClient()
    features = [videointelligence.Feature.SHOT_CHANGE_DETECTION]

    with io.open(video_link,'rb') as movie:
        input_content = movie.read()

    operation = video_client.annotate_video(
        request={"features": features, "input_content": input_content}
    )
    print("\nProcessing video for segment annotations:")

    result = operation.result().annotation_results[0]
   
    print("\nFinished processing.")
    return result
def print_video_shots(results: videointelligence.VideoAnnotationResults):
    shots = results.shot_annotations
    #shots =  results.annotation_results[0].shot_label_annotations
    print(f" Video shots: {len(shots)} ".center(40, "-"))
    for i, shot in enumerate(shots):
        t1 = shot.start_time_offset.total_seconds()
        t2 = shot.end_time_offset.total_seconds()
        print(f"{i+1:>3} | {t1:7.3f} | {t2:7.3f}")
results = detect_shot_changes(video_link)
print_video_shots(results)
