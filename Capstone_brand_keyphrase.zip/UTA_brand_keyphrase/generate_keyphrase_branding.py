import sys, detect_texts, aai_text_corpus,keyphrase_extraction
def create_keyphrase_sentiment_branding(video):
    import sys, detect_texts, aai_text_corpus,keyphrase_extraction
    import logo_df_generator
    import json
    phrase, audio_dict, audio_text, vid_text,time_list = audio_out(video)
    keyphrase=keyphrase_extraction.keyphrase_bart(phrase, audio_dict, audio_text, vid_text,time_list)
    sentiment_scores =keyphrase_extraction.vader_sentiment(phrase)
    desc=logo_df_generator.predict_logo(video)
    print(f"Branding information : ")
    print(desc)
    audio_dict_json = json.dumps(audio_dict)
    audio_text_json= json.dumps({'Audio text':audio_text})
    video_text_json= json.dumps({'Video text':vid_text})
    keyphrase_json = json.dumps({'Keyphrase':keyphrase})
    sentiment_json= json.dumps(sentiment_scores)
    logo_json=json.dumps(desc)
    
    
#     print("Keyphrase of video :")
#     print(keyphrase)
#     print("Sentiment scores of the video :")
#     print(sentiment_scores)
    return keyphrase, sentiment_scores
def audio_out(video):
    import sys, detect_texts, aai_text_corpus,keyphrase_extraction
    try:
        text_results = detect_texts.detect(video)
        vid_text=detect_texts.video_text(text_results)
        phrase, audio_dict, audio_text, vid_text,time_list = aai_text_corpus.assemblyai_text_corpus(video,vid_text)

        return phrase, audio_dict, audio_text, vid_text,time_list

    except:
        pass
    
