def lists():
    import os
    import pickle
    import warnings
    warnings.filterwarnings('ignore')
    #define the path of folder containing videos
    path = "C:/Users/manas_nmr2rze/Desktop/Capstone/AudioOutput/new_audio_out1/"
    #assign the object names to a list
    file_list=os.listdir(path)
    import re
    aud_list = []
    for string in file_list:
        m = re.search("^.*wav$", string)
        if m:
            aud_list.append(string)
    link_list=[]
    for name in aud_list:
        name = "C:/Users/manas_nmr2rze/Desktop/Capstone/AudioOutput/new_audio_out1/"+ name
        link_list.append(name)
    return link_list, aud_list
