from typing import Optional, Sequence

from google.cloud import videointelligence_v1 as vi
import io

def track_objects(
    video_uri: str, segments: Optional[Sequence[vi.VideoSegment]] = None):
    import io
    with io.open(video_uri,'rb') as movie:
        input_content = movie.read()

    video_client = vi.VideoIntelligenceServiceClient()
    features = [vi.Feature.OBJECT_TRACKING]
    context = vi.VideoContext(segments=segments)
    operation = video_client.annotate_video(
        request={"features": features, "input_content": input_content, "video_context":context}
    )
#     request = vi.AnnotateVideoRequest(
#         input_uri=video_uri,
#         features=features,
#         video_context=context,
#     )

    print(f'Processing video "{video_uri}"...')
#     operation = video_client.annotate_video(request)

    return operation.result().annotation_results[0]  # Single video
from datetime import timedelta


segment = vi.VideoSegment(
    start_time_offset=timedelta(seconds=0),
    end_time_offset=timedelta(seconds=30),
)

#objects = track_objects(video_uri, [segment])
def print_detected_objects(
    results: vi.VideoAnnotationResults, min_confidence: float = 0.0):
    annotations = results.object_annotations
    annotations = [a for a in annotations if min_confidence <= a.confidence]

    print(
        f" Detected objects: {len(annotations)}"
        f" ({min_confidence:.0%} <= confidence) ".center(80, "-")
    )
    entity_list=[]
    for annotation in annotations:
        entity = annotation.entity
        description = entity.description
        entity_id = entity.entity_id
        confidence = annotation.confidence
        t1 = annotation.segment.start_time_offset.total_seconds()
        t2 = annotation.segment.end_time_offset.total_seconds()
        frames = len(annotation.frames)
        entity_list.append((description,t1,t2,frames))
#         print(
#             f"{description:<22}",
#             f"{entity_id:<10}",
#             f"{confidence:4.0%}",
#             f"{t1:>7.3f}",
#             f"{t2:>7.3f}",
#             f"{frames:>2} fr.",
#             sep=" | ",
# )
    item_set=set([i[0] for i in entity_list])
    items = list(item_set)
    item_dir={}
    for i in items:
        item_dir[i]=[]
    for j, item in enumerate(entity_list):
        if len(item_dir[item[0]])> 0:
            item_dir[item[0]].append((entity_list[j][1],entity_list[j][2]))
            item_dir[item[0]][0]+=entity_list[j][3]
        else:
            item_dir[item[0]].append(entity_list[j][3])
            item_dir[item[0]].append((entity_list[j][1],entity_list[j][2]))
    
    item_dict={}
    for key, item in item_dir.items():
        item_dict[key]={'Total frames':item_dir[key][0], 'Timestamps':tuple(item_dir[key][1:])}
        
        

            

        
        
    return items, item_dict
def print_object_frames(
    results: vi.VideoAnnotationResults, entity_id: str, min_confidence: float = 0.0
):
    def keep_annotation(annotation: vi.ObjectTrackingAnnotation) -> bool:
        return all(
            [
                annotation.entity.entity_id == entity_id,
                min_confidence <= annotation.confidence,
            ]
        )

    annotations = results.object_annotations
    annotations = [a for a in annotations if keep_annotation(a)]
    for annotation in annotations:
        description = annotation.entity.description
        confidence = annotation.confidence
        print(
            f" {description},"
            f" confidence: {confidence:.0%},"
            f" frames: {len(annotation.frames)} ".center(80, "-")
        )
        for frame in annotation.frames:
            t = frame.time_offset.total_seconds()
            box = frame.normalized_bounding_box
            print(
                f"{t:>7.3f}",
                f"({box.left:.5f}, {box.top:.5f})",
                f"({box.right:.5f}, {box.bottom:.5f})",
                sep=" | ",
            )  
