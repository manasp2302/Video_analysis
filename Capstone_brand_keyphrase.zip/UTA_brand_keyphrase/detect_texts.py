from typing import Optional, Sequence
import io
from google.cloud import videointelligence_v1 as vi


def detect_text(
    video_uri: str,
    language_hints: Optional[Sequence[str]] = None,
    segments: Optional[Sequence[vi.VideoSegment]] = None):
    with io.open(video_uri,'rb') as movie:
        input_content = movie.read()

    video_client = vi.VideoIntelligenceServiceClient()
    features = [vi.Feature.TEXT_DETECTION]
    config = vi.TextDetectionConfig(
        language_hints=language_hints,
    )
    context = vi.VideoContext(
        segments=segments,
        text_detection_config=config,
    )
    operation = video_client.annotate_video(
        request={"features": features, "input_content": input_content, "video_context":context}
    )
#     request = vi.AnnotateVideoRequest(
#         input_uri=video_uri,
#         features=features,
#         video_context=context,
#     )

    print(f'Processing video "{video_uri}"...')
#     operation = video_client.annotate_video(request)

    return operation.result().annotation_results[0]  # Single video
def detect(video_uri):
    
    from datetime import timedelta


    segment = vi.VideoSegment(
        start_time_offset=timedelta(seconds=0),
        end_time_offset=timedelta(seconds=30),
    )

    results = detect_text(video_uri, segments=[segment])
    print_video_text(results)
    return results
def print_video_text(results: vi.VideoAnnotationResults, min_frames: int = 15):
    annotations = results.text_annotations
    sort_by_first_segment_end(annotations)

    print(" Detected Text ".center(80, "-"))
    for annotation in annotations:
        for text_segment in annotation.segments:
            frames = len(text_segment.frames)
            if frames < min_frames:
                continue
            text = annotation.text
            confidence = text_segment.confidence
            start = text_segment.segment.start_time_offset
            seconds = segment_seconds(text_segment.segment)
            print(text)
            print(f"  {confidence:4.0%} | {start} + {seconds:.1f}s | {frames} fr.")


def sort_by_first_segment_end(annotations: Sequence[vi.TextAnnotation]):
    def first_segment_end(annotation):
        return annotation.segments[0].segment.end_time_offset.ToMilliseconds()

    annotations.sort(key=first_segment_end)


def segment_seconds(segment: vi.VideoSegment) -> float:
    t1 = segment.start_time_offset.total_seconds()
    t2 = segment.end_time_offset.total_seconds()
    return t2 - t1
def video_text(results: vi.VideoAnnotationResults, min_frames: int = 15):
    annotations = results.text_annotations
    sort_by_first_segment_end(annotations)
    text_list = []

    print(" Detected Text ".center(80, "-"))
    for annotation in annotations:
        for text_segment in annotation.segments:
            frames = len(text_segment.frames)
            if frames < min_frames:
                continue
            text = annotation.text
            confidence = text_segment.confidence
            start = text_segment.segment.start_time_offset
            seconds = segment_seconds(text_segment.segment)
            print(text)
            #print(f"  {confidence:4.0%} | {start} + {seconds:.1f}s | {frames} fr.")
            text_list.append(text)
    return text_list


def sort_by_first_segment_end(annotations: Sequence[vi.TextAnnotation]):
    def first_segment_end(annotation):
        return annotation.segments[0].segment.end_time_offset.ToMilliseconds()

    annotations.sort(key=first_segment_end)


def segment_seconds(segment: vi.VideoSegment) -> float:
    t1 = segment.start_time_offset.total_seconds()
    t2 = segment.end_time_offset.total_seconds()
    return t2 - t1
def print_text_frames(results: vi.VideoAnnotationResults, contained_text: str):
    # Vertex order: top-left, top-right, bottom-right, bottom-left
    def box_top_left(box: vi.NormalizedBoundingPoly) -> str:
        tl = box.vertices[0]
        return f"({tl.x:.5f}, {tl.y:.5f})"

    def box_bottom_right(box: vi.NormalizedBoundingPoly) -> str:
        br = box.vertices[2]
        return f"({br.x:.5f}, {br.y:.5f})"

    annotations = results.text_annotations
    annotations = [a for a in annotations if contained_text in a.text]
    for annotation in annotations:
        print(f" {annotation.text} ".center(80, "-"))
        for text_segment in annotation.segments:
            for frame in text_segment.frames:
                frame_ms = frame.time_offset.total_seconds()
                box = frame.rotated_bounding_box
                print(
                    f"{frame_ms:>7.3f}",
                    box_top_left(box),
                    box_bottom_right(box),
                    sep=" | ",
                )
                
