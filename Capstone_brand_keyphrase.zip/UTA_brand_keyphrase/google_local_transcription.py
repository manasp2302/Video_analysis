def local_google_transcribe(vid_link):
    
    import os
    import speech_recognition as sr
    import ffmpeg
    #import soundfile
    import numpy as np
    #import librosa
    import glob

    import matplotlib.pyplot as plt
    #import librosa.display
    from IPython.display import Audio, display
    from google.cloud import speech
    import io
    for name in vid_list:
        if name in vid_link:
            n=name
    audio_out_link = "C:/Users/manas_nmr2rze/Desktop/Capstone/AudioOutput/"+"output"+".wav"
    from pydub import AudioSegment
    #convert video to audio
    import moviepy.editor as mp
    # Insert Local Video File Path
    clip = mp.VideoFileClip(vid_link)

    # Insert Local Audio File Path
    clip.audio.write_audiofile(audio_out_link)
    sound = AudioSegment.from_wav(audio_out_link)
    sound = sound.set_channels(1)
    sound.export(audio_out_link, format="wav")
    words =[]
    word_dict = {}
    word_str = ''

    client = speech.SpeechClient()
    #path = audio_out_link
    # path = 'resources/commercial_mono.wav'
    with io.open(audio_out_link, "rb") as audio_file:
        content = audio_file.read()

    audio = speech.RecognitionAudio(content=content)
    config = speech.RecognitionConfig(
        encoding=speech.RecognitionConfig.AudioEncoding.LINEAR16,
        sample_rate_hertz=44100,
        language_code="en-US",
        # Enable automatic punctuation
        enable_automatic_punctuation=True,
        enable_word_time_offsets=True,

    )
#     print(f"start_time      end_time        Word   ")
#     print("=======================================")
    response = client.recognize(config=config, audio=audio)
    for result in response.results:
        alternative = result.alternatives[0]
    #     print("Transcript: {}".format(alternative.transcript))
    #     print("Confidence: {}".format(alternative.confidence))


        for word_info in alternative.words:
            word = word_info.word
            word = word.lower()
            start_time = word_info.start_time
            end_time = word_info.end_time
            words.append(word)
            word_str= word_str+' '+word
            word_dict[word]=(start_time.total_seconds(), end_time.total_seconds())
#             print(f"{start_time.total_seconds():.2f}      \t{end_time.total_seconds():.2f}    \t{word}")
    return words, word_dict, word_str
