def lists(path):
    import os
    import pickle
    import warnings
    warnings.filterwarnings('ignore')
    #define the path of folder containing videos
    #path = "C:/Users/manas_nmr2rze/Desktop/Capstone/"+folder 
    #assign the object names to a list
    file_list=os.listdir(path)
    import re
    vid_list = []
    for string in file_list:
        m = re.search("^.*mp4$", string)
        if m:
            vid_list.append(string)
    link_list=[]
    for name in vid_list:
        name = path +"/"+ name
        link_list.append(name)
    return link_list, vid_list

