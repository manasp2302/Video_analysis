from typing import Optional, Sequence

from google.cloud import videointelligence_v1 as vi


def detect_labels(
    video_uri,
    mode: vi.LabelDetectionMode,
    segments: Optional[Sequence[vi.VideoSegment]] = None,):
    with io.open(video_uri,'rb') as movie:
        input_content = movie.read()
    video_client = vi.VideoIntelligenceServiceClient()
    features = [vi.Feature.LABEL_DETECTION]
    config = vi.LabelDetectionConfig(label_detection_mode=mode)
    context = vi.VideoContext(segments=segments, label_detection_config=config)
    operation = video_client.annotate_video(
        request={"features": features, "input_content": input_content, "video_context":context},
    mode = vi.LabelDetectionMode.SHOT_MODE
    )
#     request = vi.AnnotateVideoRequest(
#         input_uri=input_content,
#         features=features,
#         video_context=context,
#     )


    print(f'Processing video "{video_uri}"...')
    #operation = video_client.annotate_video(request)

    return operation.result().annotation_results[0]  # Single video
from datetime import timedelta


mode = vi.LabelDetectionMode.SHOT_MODE
segment = vi.VideoSegment(
    start_time_offset=timedelta(seconds=0),
    end_time_offset=timedelta(seconds=30),
)

#label = detect_labels(video_uri, mode, [segment])
def print_video_labels(results: vi.VideoAnnotationResults):
    labels = results.segment_label_annotations
    sort_by_first_segment_confidence(labels)

    print(f" Video labels: {len(labels)} ".center(80, "-"))
    for label in labels:
        categories = category_entities_to_str(label.category_entities)
        for segment in label.segments:
            confidence = segment.confidence
            t1 = segment.segment.start_time_offset.total_seconds()
            t2 = segment.segment.end_time_offset.total_seconds()
            print(
                f"{confidence:4.0%}",
                f"{t1:7.3f}",
                f"{t2:7.3f}",
                f"{label.entity.description}{categories}",
                sep=" | ",
            )


def sort_by_first_segment_confidence(labels: Sequence[vi.LabelAnnotation]):
    labels.sort(key=lambda label: label.segments[0].confidence, reverse=True)


def category_entities_to_str(category_entities: Sequence[vi.Entity]) -> str:
    if not category_entities:
        return ""
    entities = ", ".join([e.description for e in category_entities])
    return f" ({entities})"
#video_labels=print_video_labels(label)
def print_shot_labels(results: vi.VideoAnnotationResults):
    labels = results.shot_label_annotations
    sort_by_first_segment_start_and_confidence(labels)

    print(f" Shot labels: {len(labels)} ".center(80, "-"))
    for label in labels:
        categories = category_entities_to_str(label.category_entities)
        print(f"{label.entity.description}{categories}")
        for segment in label.segments:
            confidence = segment.confidence
            t1 = segment.segment.start_time_offset.total_seconds()
            t2 = segment.segment.end_time_offset.total_seconds()
            print(f"{confidence:4.0%} | {t1:7.3f} | {t2:7.3f}")


def sort_by_first_segment_start_and_confidence(labels: Sequence[vi.LabelAnnotation]):
    def first_segment_start_and_confidence(label):
        first_segment = label.segments[0]
        ms = first_segment.segment.start_time_offset.ToMilliseconds()
        return (ms, -first_segment.confidence)

    labels.sort(key=first_segment_start_and_confidence)
#print_shot_labels(label)
