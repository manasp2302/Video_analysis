from typing import Optional, Sequence

from google.cloud import videointelligence_v1 as vi
def logo_and_frames(video):
    detect_logos(video)

    results = detect_logos(video, [segment])
    entity = print_detected_logos(results)
    detect_logo(local_file_path=video)
    #print(detect_logos(video))

def detect_logos(
    video_uri: str, segments: Optional[Sequence[vi.VideoSegment]] = None):
    with io.open(video_uri,'rb') as movie:
        input_content = movie.read()

    video_client = vi.VideoIntelligenceServiceClient()
    features = [vi.Feature.LOGO_RECOGNITION]
    context = vi.VideoContext(segments=segments)
    operation = video_client.annotate_video(
        request={"features": features, "input_content": input_content, "video_context":context}
    )
#     request = vi.AnnotateVideoRequest(
#         input_uri=video_uri,
#         features=features,
#         video_context=context,
#     )

    print(f'Processing video "{video_uri}"...')
#     operation = video_client.annotate_video(request)

    return operation.result().annotation_results[0]  # Single video
from datetime import timedelta


segment = vi.VideoSegment(
    start_time_offset=timedelta(seconds=0),
    end_time_offset=timedelta(seconds=30),
)

#results = detect_logos(video_uri, [segment])  
def print_detected_logos(results: vi.VideoAnnotationResults):
    annotations = results.logo_recognition_annotations
    frame_dict = {}
    frame_list=[]
    entity_list=[]
    logo_timestamp=[]


    print(f" Detected logos: {len(annotations)} ".center(80, "-"))
    for annotation in annotations:
        entity = annotation.entity
        entity_id = entity.entity_id
        description = entity.description
        frame_dict[description]=0
        for track in annotation.tracks:
            confidence = track.confidence
            t1 = track.segment.start_time_offset.total_seconds()
            t2 = track.segment.end_time_offset.total_seconds()
            logo_frames = len(track.timestamped_objects)
            frame_dict[description]+=len(track.timestamped_objects)
            logo_timestamp.append((description,track.segment.start_time_offset.total_seconds(),
                                   track.segment.end_time_offset.total_seconds()))
            print(
                f"{confidence:4.0%}",
                f"{t1:>7.3f}",
                f"{t2:>7.3f}",
                f"{logo_frames:>3} fr.",
                f"{entity_id:<15}",
                f"{description}",                
                sep=" | ",
            )
    for key, value in frame_dict.items():
        entity_list.append(key)
        frame_list.append(value)
    max_frame = max(frame_list)
    max_frame_entity = entity_list[frame_list.index(max(frame_list))]
    print(f"Logo with max frames: {max_frame_entity}")
    
    print("Total frames with","'",max_frame_entity,"'", f"logo: {max_frame}")
    sorted_frame_list, sorted_frame_dict=create_entity_output(frame_dict)
    return sorted_frame_list, sorted_frame_dict, logo_timestamp
            
#f"{area_dict[entity_id]}",
def print_logo_frames(results: vi.VideoAnnotationResults, entity_id: str):
    def keep_annotation(annotation: vi.LogoRecognitionAnnotation) -> bool:
        return annotation.entity.entity_id == entity_id

    annotations = results.logo_recognition_annotations
    annotations = [a for a in annotations if keep_annotation(a)]
    for annotation in annotations:
        description = annotation.entity.description
        for track in annotation.tracks:
            confidence = track.confidence
            print(
                f" {description},"
                f" confidence: {confidence:.4%},"
                f" frames: {len(track.timestamped_objects)} ".center(80, "-")
            )
            for timestamped_object in track.timestamped_objects:
                t = timestamped_object.time_offset.total_seconds()
                box = timestamped_object.normalized_bounding_box
                print(
                    f"{t:>7.3f}",
                    f"({box.left:.5f}, {box.top:.5f})",
                    f"({box.right:.5f}, {box.bottom:.5f})",
                    sep=" | ",
                )
import io

from google.cloud import videointelligence


def detect_logo(local_file_path):
    from statistics import mean
    from collections import Counter
    """Performs asynchronous video annotation for logo recognition on a local file."""

    client = videointelligence.VideoIntelligenceServiceClient()

    with io.open(local_file_path, "rb") as f:
        input_content = f.read()
    features = [videointelligence.Feature.LOGO_RECOGNITION]

    operation = client.annotate_video(
        request={"features": features, "input_content": input_content}
    )

    print("Waiting for operation to complete...")
    response = operation.result()

    # Get the first response, since we sent only one video.
    annotation_result = response.annotation_results[0]
    ent_list = []
    ent_dir={}
    ent_dir_val={}
    frame_dict={}
    area_list=[]
    ent_id_list=[]
    logo_pos_dict,logo_dict_out ={},{}
    logo_pos_list=[]
    max_logo_list=[]
    empty_list=[]
    empty_list2=[]
    logo_timestamp_list=[]
    logo_position={1:"Top left", 2:"Left center", 3:"Lower left",4:"Bottom center",5:"Lower right",
                  6:"Right center",7:"Top right",8:"Top center", 9:"Center of screen", 10:"Not sure"}

    # Annotations for list of logos detected, tracked and recognized in video.
    for  logo_recognition_annotation in annotation_result.logo_recognition_annotations:
        entity = logo_recognition_annotation.entity

        # Opaque entity ID. Some IDs may be available in [Google Knowledge Graph
        # Search API](https://developers.google.com/knowledge-graph/).
        print("Entity Id : {}".format(entity.entity_id))

        print("Description : {}".format(entity.description))
        
        ent_list.append(entity.description)
        frame_dict[entity.description] = 0
        ent_id_list.append(entity.entity_id)
        

        # All logo tracks where the recognized logo appears. Each track corresponds
        # to one logo instance appearing in consecutive frames.
        for j, track in enumerate(logo_recognition_annotation.tracks):
            ent_dir[f"{entity.description}_{j}"]=(f"Start time:{(float(track.segment.start_time_offset.seconds))+(float(track.segment.start_time_offset.microseconds)/1000000)}",
                                         f"End time: {(float(track.segment.end_time_offset.seconds)+float(track.segment.end_time_offset.microseconds/1000000))}",
                                         f"Duration of logo: {round(((float(track.segment.end_time_offset.seconds))+(float(track.segment.end_time_offset.microseconds)/1000000))-((float(track.segment.start_time_offset.seconds))+(float(track.segment.start_time_offset.microseconds)/1000000)),3)}",
                                         f"Confidence: {round(track.confidence*100,2)}%")
            ent_dir_val[entity.description]=(((float(track.segment.start_time_offset.seconds))+(float(track.segment.start_time_offset.microseconds)/1000000),
                                         (float(track.segment.end_time_offset.seconds)+float(track.segment.end_time_offset.microseconds/1000000)),
                                         round(((float(track.segment.end_time_offset.seconds))+(float(track.segment.end_time_offset.microseconds)/1000000))-((float(track.segment.start_time_offset.seconds))+(float(track.segment.start_time_offset.microseconds)/1000000)),3)))
            logo_pos_dict[entity.description]=0
#             max_logo_dict[entity.description]=0
            x=0
            logo_pos_lst=[]
            ctr={}
            # Video segment of a track.
            print(
                "\n\tStart Time Offset : {}.{}".format(
                    track.segment.start_time_offset.seconds,
                    track.segment.start_time_offset.microseconds * 1000,
                )
            )
            print(
                "\tEnd Time Offset : {}.{}".format(
                    track.segment.end_time_offset.seconds,
                    track.segment.end_time_offset.microseconds * 1000,
                )
            )
#             print("\tConfidence : {}".format(track.confidence))
#             print(f" Area covered: {mean(area_lst)}")
#             print(f" frames: {len(track.timestamped_objects)} ".center(80, "-"))
            
            if frame_dict[entity.description] is not None:
                
                frame_dict[entity.description] = frame_dict[entity.description]+len(track.timestamped_objects)
            else:
                frame_dict[entity.description]= len(track.timestamped_objects)
            
            area_lst = []
            for timestamped_object in track.timestamped_objects:

                # Normalized Bounding box in a frame, where the object is located.
                normalized_bounding_box = timestamped_object.normalized_bounding_box
                Area=(float(normalized_bounding_box.bottom)-float(normalized_bounding_box.top))*(float(normalized_bounding_box.right)-float(normalized_bounding_box.left))*100
                area_lst.append(Area)
                
            area_list.append((entity.description, f"{round(mean(area_lst),4)}%"))    
            print("\tConfidence : {}".format(track.confidence))
            print(f"\tAverage area covered: {round(mean(area_lst),4)}%")
            
            for timestamped_object in track.timestamped_objects:
                normalized_bounding_box = timestamped_object.normalized_bounding_box                
                position=detect_position(normalized_bounding_box.top,normalized_bounding_box.left,normalized_bounding_box.bottom,normalized_bounding_box.right)
                logo_pos_lst.append(logo_position[position])
                #area_lst.append(Area)
            
            for i in logo_pos_lst:
                ctr[i]=logo_pos_lst.count(i)
            for k, v in ctr.items():
                if v>x:
                    x=v
                    max_appear=k
                    count=x
                else:
                    continue
            
#             if logo_pos_dict[entity.description] != None:
            max_logo_list.append((entity.description,max_appear, count))
#             if max_logo_dict[max_appear] != None:                
#                 max_logo_dict[max_appear]+=logo_pos_dict[max_appear]
            print(f"\tMax appeared logo position: {max_appear} ")
            print(f"\tframes: {len(track.timestamped_objects)} ".center(80, "-"))
                

            
            
            # The object with timestamp and attributes per frame in the track.

            logo = entity.description
            for i,timestamped_object in enumerate(track.timestamped_objects):

#                 Normalized Bounding box in a frame, where the object is located.
                normalized_bounding_box = timestamped_object.normalized_bounding_box
                Area=(float(normalized_bounding_box.bottom)-float(normalized_bounding_box.top))*(float(normalized_bounding_box.right)-float(normalized_bounding_box.left))*100
                position=detect_position(normalized_bounding_box.top,normalized_bounding_box.left,normalized_bounding_box.bottom,normalized_bounding_box.right)
                print("\n\t\tLeft : {}".format(normalized_bounding_box.left))
                print("\t\tTop : {}".format(normalized_bounding_box.top))
                print("\t\tRight : {}".format(normalized_bounding_box.right))
                print("\t\tBottom : {}".format(normalized_bounding_box.bottom))
                print("\t\tPercentage of screen covered :{}%".format(round(Area,3)))
                print("\t\tLogo position :{}".format(logo_position[position]))
                logo_pos_lst.append(logo_position[position])
                #area_lst.append(Area)
                logo_dict_out[f'{logo}_{j}_{i}']={"Logo ":logo,
                                                                "Percentage of screen covered ":f"{(round(Area,3))}%",
                                                                "Logo position ":(logo_position[position])}

            


            logo_out={}
            for key, item in ent_dir.items():
                lst=[]
                str=''
                cont=''
                for m, n in logo_dict_out.items():
                    if key in m:
                        lst.append(n)
                for i in item:
                    str=str+i
               
                    
                logo_out[str]=tuple(lst)
                    
                    
                

                # Optional. The attributes of the object in the bounding box.
                for attribute in timestamped_object.attributes:
                    print("\n\t\t\tName : {}".format(attribute.name))
                    print("\t\t\tConfidence : {}".format(attribute.confidence))
                    print("\t\t\tValue : {}".format(attribute.value))

            # Optional. Attributes in the track level.
            for track_attribute in track.attributes:
                print("\n\t\tName : {}".format(track_attribute.name))
                print("\t\tConfidence : {}".format(track_attribute.confidence))
                print("\t\tValue : {}".format(track_attribute.value))

        # All video segments where the recognized logo appears. There might be
        # multiple instances of the same logo class appearing in one VideoSegment.
        for segment in logo_recognition_annotation.segments:
            logo_timestamp_list.append((entity.description,{segment.start_time_offset.seconds,
                    segment.start_time_offset.microseconds * 1000,},{segment.end_time_offset.seconds,
                    segment.end_time_offset.microseconds * 1000,}))
            print(
                "\n\tStart Time Offset : {}.{}".format(
                    segment.start_time_offset.seconds,
                    segment.start_time_offset.microseconds * 1000,
                )
            )
            print(
                "\tEnd Time Offset : {}.{}".format(
                    segment.end_time_offset.seconds,
                    segment.end_time_offset.microseconds * 1000,
                )
                
            )
    return area_list, max_logo_list,logo_out

def detect_position(top, left, bottom, right):
    try:
        if top<.5 and left<.5 and bottom<=.5 and right<=.5:
            return 1
        if top<=.5 and left<.5 and bottom>=.5 and right<=.5:
            return 2
        if top>=.5 and left<.5 and bottom>.5 and right<=.5:
            return 3
        if top>=.5 and left<.5 and bottom>.5 and right>.5:
            return 4
        if top>=.5 and left>=.5 and bottom>.5 and right>.5:
            return 5
        if top<=.5 and left>=.5 and bottom>.5 and right>.5:
            return 6
        if top<.5 and left>=.5 and bottom<=.5 and right>.5:
            return 7
        if top<.5 and left<=.5 and bottom<=.5 and right>.5:
            return 8
        if top<.5 and left<.5 and bottom>.5 and right>.5:
            return 9
    except:
        return 10
#     if len(ent_list)>=1:
#         max=0
#         ide =''
#         max_dic ={}
#         for key, value in ent_dir_val.items():
            
#             if value[2]>max:
#                 max=value[2]
#                 ide = key
#         max_dic[ide] = max
                
def create_entity_output(frame_dict):
    sorted_frame_list = sorted(frame_dict.items(), key=lambda x:x[1],reverse=True)
    sorted_frame_dict = dict(sorted_frame_list)
    if len(sorted_frame_list)>5:
        sorted_frame_list=sorted_frame_list[:5]
    while len(sorted_frame_list)<5:
        sorted_frame_list.append((0,0))
    return sorted_frame_list, sorted_frame_dict
        
        
        
        
    
        
    
            
            
        
#         print(f"Logos found in video: {ent_list}")
#         print(f"Frames per logo in video: {frame_dict}")
#         print(f"Max duaration in video : Logo: {ide}, Duration: {max}")
#         print(f"First logo in video: {ent_list[0]} : {ent_dir[ent_list[0]]}")
#         print(f"Last logo in video: {ent_list[-1]} : {ent_dir[ent_list[-1]]}")
#     else:
#         pass
        
