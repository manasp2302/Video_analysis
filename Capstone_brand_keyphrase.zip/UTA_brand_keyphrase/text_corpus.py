def google_text_corpus(video_link):
    words, word_dict,audio_text=local_google_transcribe(video_link)
#     print(audio_text)
    ph = key_phrase(video_link)
#     print(ph)
    phrase = audio_text+ph
    return phrase
def openai_text_corpus(video_link):
    import pickle
    speech_rec_converter = pickle.load(open('speech_rec_converter.pkl','rb'))
    aud_text = speech_rec_converter(video_link)
   
#     print(aud_text['text'])
    ph = key_phrase(video_link)
#     print(ph)
    phrase = aud_text['text']+' '+ph
    return phrase
def assemblyai_text_corpus(video_link):
    import moviepy.editor as mp
    # Insert Local Video File Path
    audio_out_link = "C:/Users/manas_nmr2rze/Desktop/Capstone/AudioOutput/"+'output'+".wav"
    clip = mp.VideoFileClip(video_link)

    # Insert Local Audio File Path
    clip.audio.write_audiofile(audio_out_link)
    audio_text, audio_dict = aai_audio_transcription(audio_out_link)

   
#     print(aud_text['text'])
    ph = key_phrase(video_link)
#     print(ph)
    phrase = audio_text+' '+ph
    return phrase, audio_dict,keyphrase_rank,keyphrase_timestamp
def aai_audio_transcription(audio_out_link):
    import requests
    import time
    import string
    UPLOAD_ENDPOINT = "https://api.assemblyai.com/v2/upload"
    TRANSCRIPTION_ENDPOINT = "https://api.assemblyai.com/v2/transcript"
    api_key = "1c9d460c0979424d8602d6b37dabcca8"
    headers = {"authorization": api_key, "content-type": "application/json","auto_highlights": 'True',"iab_categories": 'True'}
    def read_file(filename):
       with open(filename, 'rb') as _file:
           while True:
               data = _file.read(5242880)
               if not data:
                   break
               yield data
    upload_response = requests.post(UPLOAD_ENDPOINT, headers=headers, data=read_file(audio_out_link))
    audio_url = upload_response.json()["upload_url"]
    transcript_request = {'audio_url': audio_url}
    transcript_response = requests.post(TRANSCRIPTION_ENDPOINT, json=transcript_request, headers=headers)
    _id = transcript_response.json()["id"]
    # _confidence = transcript_response.json()["confidence"]
    # _audio_duration = transcript_response.json()["audio_duration"]
    while True:

        polling_response = requests.get(TRANSCRIPTION_ENDPOINT+"/"+_id, headers=headers)

        if polling_response.json()['status'] == 'completed':


            aai_word_text = str((polling_response.json()['text']))
            audio_dict = (polling_response.json()['words'])

            break






    #         with open(f"{_id}.txt", 'w') as f:



    #             #f.write(polling_response.json()['text'])
    #             #f.write(str(polling_response.json()['confidence']))
    #             f.write(str(polling_response.json()['words']))

    #             print(f"Transcript saved to {_id}.txt")
    #             break
        elif polling_response.json()['status'] == 'error':


            raise Exception("Transcription failed. Make sure a valid API key has been used.")
        else:
            print("Transcription queued or processing ...")
        time.sleep(5)
    aai_word_dict = {}
    for i in range(len(audio_dict)):
        removePuncuation= audio_dict[i]['text'].translate(str.maketrans('', '', string.punctuation)).lower()
        
        
    
        aai_word_dict[removePuncuation]=(audio_dict[i]['start']/1000,
                                              audio_dict[i]['end']/1000,
                                              audio_dict[i]['confidence'])
    return aai_word_text, aai_word_dict
