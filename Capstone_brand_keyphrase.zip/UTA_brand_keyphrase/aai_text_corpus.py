def assemblyai_text_corpus(video_link,gen_text):# get_text is gen_text = video_text(text_results)
    import moviepy.editor as mp
    
    import string
    # Insert Local Video File Path
    audio_out_link = "C:/Users/manas_nmr2rze/Desktop/Capstone/AudioOutput/"+'output'+".wav"
    clip = mp.VideoFileClip(video_link)

    # Insert Local Audio File Path
    clip.audio.write_audiofile(audio_out_link)
   
    audio_text, audio_dict, aai_time= aai_audio_transcription(audio_out_link)
    string = ''
    for word in gen_text:
        string=string+' '+word
        

    text = string.split(' ')
    vid_text ='' 
    for i in text:
        vid_text = vid_text+i+' ' 
    vid_text = str(vid_text).lower()

    phrase = audio_text+' '+ vid_text

    return phrase, audio_dict, audio_text, vid_text, aai_time

def aai_audio_transcription(audio_out_link):
    import requests
    import time
    import string
    with open("aai_key.txt") as f:
        contents = f.readlines()
        for i in contents:
            aai_api_key = i
    UPLOAD_ENDPOINT = "https://api.assemblyai.com/v2/upload"
    TRANSCRIPTION_ENDPOINT = "https://api.assemblyai.com/v2/transcript"
    api_key = str(aai_api_key)
    headers = {"authorization": api_key, "content-type": "application/json","auto_highlights": 'True',"iab_categories": 'True'}
    def read_file(filename):
       with open(filename, 'rb') as _file:
           while True:
               data = _file.read(5242880)
               if not data:
                   break
               yield data
    upload_response = requests.post(UPLOAD_ENDPOINT, headers=headers, data=read_file(audio_out_link))
    audio_url = upload_response.json()["upload_url"]
    transcript_request = {'audio_url': audio_url}
    transcript_response = requests.post(TRANSCRIPTION_ENDPOINT, json=transcript_request, headers=headers)
    _id = transcript_response.json()["id"]
    # _confidence = transcript_response.json()["confidence"]
    # _audio_duration = transcript_response.json()["audio_duration"]
    while True:

        polling_response = requests.get(TRANSCRIPTION_ENDPOINT+"/"+_id, headers=headers)

        if polling_response.json()['status'] == 'completed':


            aai_word_text = str((polling_response.json()['text']))
            audio_dict = (polling_response.json()['words'])

            break



    #         with open(f"{_id}.txt", 'w') as f:



    #             #f.write(polling_response.json()['text'])
    #             #f.write(str(polling_response.json()['confidence']))
    #             f.write(str(polling_response.json()['words']))

    #             print(f"Transcript saved to {_id}.txt")
    #             break
        elif polling_response.json()['status'] == 'error':


            raise Exception("Transcription failed. Make sure a valid API key has been used.")
        else:
            print("Transcription queued or processing ...")
        time.sleep(5)
    aai_word_dict = {}
    aai_time_list = []
    for i in range(len(audio_dict)):
        removePuncuation= audio_dict[i]['text'].translate(str.maketrans('', '', string.punctuation)).lower()
        
        
    
        aai_word_dict[removePuncuation]=(audio_dict[i]['start']/1000,
                                              audio_dict[i]['end']/1000,
                                              audio_dict[i]['confidence'])
        aai_time_list.append((audio_dict[i]['start']/1000,
                                              audio_dict[i]['end']/1000,
                                              audio_dict[i]['confidence']))
    return aai_word_text, aai_word_dict, aai_time_list

def generate_audiofiles(audio_folder_path,links_list):
    
    import moviepy.editor as mp
    import string
    
    link_list, vid_list = links_list.lists()
    for name in vid_list:
        try:


            for link in link_list:
                if name in link:
                    video = name
                    vlink = link
        except:
            continue
        try:

            # Insert Local Video File Path
            name=video.replace('.mp4','')
            audio_out_link = audio_folder_path+name+".wav"
            clip = mp.VideoFileClip(vlink)

            # Insert Local Audio File Path
            clip.audio.write_audiofile(audio_out_link)
        except:
            continue
