def generate_logo_dataframe(video_link,df,col_list):
    #generate empty dataframe and pass it the function
    from UTA_brand_keyphrase import detect_logo
    try:
        area_list, max_logo_list, logo_out=detect_logo.detect_logo(video_link)
    except:
        return "Logo detection is not possible..."
    try:
        results = detect_logo.detect_logos(video_link)
        sorted_frame_list, sorted_frame_dict, logo_timestamp = detect_logo.print_detected_logos(results)
    except:
        return "Logo not printed"
    try:
    
        avg_area_dict=avg_area_logo(area_list)
        max_logo_pos_dict=max_appeared_logo_pos(max_logo_list)
    except:
        return "Average area and max appeared position counting is not possible"
    try:
        
        logo_dataframe=add_data(video_link,avg_area_dict,max_logo_pos_dict,sorted_frame_dict,sorted_frame_list, df, col_list)
        return logo_dataframe, sorted_frame_list, sorted_frame_dict,avg_area_dict,max_logo_pos_dict, logo_timestamp,logo_out
    except:
        pass


def make_empty_df():
    import pandas as pd

    df = pd.DataFrame(columns=['logo_1_total_frames','logo_2_total_frames','logo_3_total_frames','logo_4_total_frames',
                               'logo_5_total_frames','logo_1_avg_logo_size','logo_2_avg_logo_size','logo_3_avg_logo_size',
                               'logo_4_avg_logo_size','logo_5_avg_logo_size','logo_1_most_appeared_position',
                               'logo_2_most_appeared_position','logo_3_most_appeared_position','logo_4_most_appeared_position',
                               'logo_5_most_appeared_position','video','logos'])
    col_list=[df.columns[0], df.columns[1],df.columns[2],
          df.columns[3],df.columns[4],df.columns[5],
          df.columns[6],df.columns[7],df.columns[8],
          df.columns[9],df.columns[10],df.columns[11],
          df.columns[12],df.columns[13],df.columns[14],df.columns[15],df.columns[16]]
    
    return df, col_list    
    
    
    
def avg_area_logo(area_list):# first output from detect logo function
    area_set=set()
    avg_area_dict={}
    for i, x in enumerate(area_list):
        area_set.add(x[0])
    for i, x in enumerate(area_set):
        avg_area_dict[x]=0
        c=0
        for j in area_list:
            if x==j[0]:
                c+=1
                avg_area_dict[x]+= float(j[1].replace('%',''))
        avg_area_dict[x]= avg_area_dict[x]/c
    return avg_area_dict

def max_appeared_logo_pos(max_logo_list): # second output from detect logo function
    max_logo_set=set()
    max_logo_pos_dict={}
    for i, x in enumerate(max_logo_list):
        max_logo_set.add(x[0])
    for i, x in enumerate(max_logo_set):
        max_logo_pos_dict[x]=[]
        c=0
        for j in max_logo_list:
            if x==j[0]:
                max_logo_pos_dict[x].append(j[1])
        max_logo_pos_dict[x]= max_count(max_logo_pos_dict[x])
    return max_logo_pos_dict
def max_count(list_name):
    from collections import Counter
    counter = Counter(list_name)
    max_count_object = counter.most_common(1)
    max_count_object = max_count_object[0][0]
    return max_count_object



def add_data(video_link,avg_area_dict,max_logo_pos_dict,sorted_frame_dict,sorted_frame_list, df, col_list):

    import pandas as pd
    item_dic={}
    item_list=[]
    for i in range(len(sorted_frame_dict)):
        item_list.append(sorted_frame_dict[sorted_frame_list[i][0]])
        item_list.append(avg_area_dict[sorted_frame_list[i][0]])
        item_list.append(max_logo_pos_dict[sorted_frame_list[i][0]])
 
    j=0
    for i in range(len(sorted_frame_dict)):    
        item_dic[col_list[i]]=item_list[j]
        item_dic[col_list[i+5]]=item_list[j+1]
        item_dic[col_list[i+10]]=item_list[j+2]
        j+=3
    item_dic[col_list[15]]= video_link
    item_dic[col_list[16]]=[key for key, value in sorted_frame_dict.items()]
    new_row=[item_dic]

    df = df.append(new_row, ignore_index=True)
    return df

def predict_logo(video_link):
   
    import pandas as pd
    from sklearn.ensemble import GradientBoostingClassifier
    import pickle
    rf_model = pickle.load(open('rf_model.pkl','rb'))
    df,col_list= make_empty_df()    
    logo_df, sorted_frame_list, sorted_frame_dict,avg_area_dict,max_logo_pos_dict, logo_timestamp,logo_out=generate_logo_dataframe(video_link,df,col_list)
    logo_position={"Top left":1, "Left center":2, "Lower left":3,"Bottom center":4,"Lower right":5,
              "Right center":6,"Top right":7,"Top center":8, "Center of screen":9, "Not sure":10}
    logo_df['logo_1_most_appeared_position']=logo_df['logo_1_most_appeared_position'].map(logo_position)
    logo_df['logo_2_most_appeared_position']=logo_df['logo_2_most_appeared_position'].map(logo_position)
    logo_df['logo_3_most_appeared_position']=logo_df['logo_3_most_appeared_position'].map(logo_position)
    logo_df['logo_4_most_appeared_position']=logo_df['logo_4_most_appeared_position'].map(logo_position)
    logo_df['logo_5_most_appeared_position']=logo_df['logo_5_most_appeared_position'].map(logo_position)
    logo_df = logo_df.drop(columns=['video', 'logos'], axis=1)
    logo_df= logo_df.fillna(0)
    logo_out_dict={}
    timestamps=[]
    timestamps1=[]
    
    predict = rf_model.predict(logo_df.iloc[0:1])
    index= int(predict[0])-1
    logo = sorted_frame_list[index][0]
    for i , x in enumerate(logo_timestamp):
        if logo_timestamp[i][0]== logo:
            timestamps.append((logo_timestamp[i][1], logo_timestamp[i][2]))
    try:

        logo_out_dict['Logo'] = logo
    except:
        pass
    try:
        logo_out_dict['Total_frames'] = sorted_frame_dict[logo]
    except:
        pass
    try:
        logo_out_dict['Avg_area'] = avg_area_dict[logo]
    except:
        pass
    try:
        logo_out_dict['Max_appeared_position'] = max_logo_pos_dict[logo]
    except:
        pass
    try:
  
        logo_out_dict['Timestamps']= timestamps
    except:
        pass
  
    

    return logo_out_dict,logo_out,logo

    
    
    
    
 
