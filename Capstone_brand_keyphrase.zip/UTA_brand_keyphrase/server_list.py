#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import re


# In[25]:


server= pd.read_csv("server_data.txt", delimiter='\t')


server.drop(server.tail(1).index, inplace=True)


# In[26]:


server


# In[27]:


new = server.loc[(server['iLO Name']!='Absent')&(server['Status']=='On')]


# In[6]:


new


# In[28]:


Bay_name = list(new['Bay'])
List=[]


# In[23]:


for i in range(len(Bay_name)):
    Bay_name[i]= int(Bay_name[i])

    


# In[24]:


return Bay_name


# In[ ]:




